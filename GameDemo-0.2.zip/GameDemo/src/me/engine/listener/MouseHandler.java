package me.engine.listener;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;



public class MouseHandler  implements  MouseListener,MouseMotionListener {

	


	public MouseHandler(){
	}
	@Override
	public void mouseClicked(MouseEvent event) {
	
		
	}
    

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {

	}

	@Override
	public void mouseReleased(MouseEvent event) {
		
	}
	@Override
	public void mouseDragged(MouseEvent arg0) {
		
		
		
	}
	@Override
	public void mouseMoved(MouseEvent event) {

	}

}
