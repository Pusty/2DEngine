package me.test;

import me.engine.main.Engine;

public class EntityPlayerMP extends Player{

	public EntityPlayerMP(Engine e,int a, int b) {
		super(e,a, b);
	}
	
	

}
