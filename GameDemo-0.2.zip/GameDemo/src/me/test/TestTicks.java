package me.test;

import me.engine.effects.Particle;
import me.engine.listener.KeyHandler;
import me.engine.location.Location;
import me.engine.main.Engine;
import me.engine.main.GameTicks;
import me.engine.object.Entity;

public class TestTicks extends GameTicks {

	
	


	
	
	Engine engine;
	public TestTicks(Engine e){
		super(e);
		engine = e;
	}
	@Override
	public void run() {
		

		while(true){

	        		if(engine.getWorld() != null && engine.getWorld().getPlayer() != null && engine.getPhysics() != null){

	        			
	        			

	        			
	        			if(((KeyHandler)engine.getKeyListeners()[0]).up)
	        			engine.getPhysics().usePhysics(engine.getWorld().getPlayer(), engine.getWorld().getPlayer().getLocation().getX(),engine.getWorld().getPlayer().getLocation().getY()-5);
	        			if(((KeyHandler)engine.getKeyListeners()[0]).down)
	        			engine.getPhysics().usePhysics(engine.getWorld().getPlayer(),engine.getWorld().getPlayer().getLocation().getX(),engine.getWorld().getPlayer().getLocation().getY()+5);
	        			
	        			if(((KeyHandler)engine.getKeyListeners()[0]).left)
	        			engine.getPhysics().usePhysics(engine.getWorld().getPlayer(),engine.getWorld().getPlayer().getLocation().getX()-5,engine.getWorld().getPlayer().getLocation().getY());
	        			if(((KeyHandler)engine.getKeyListeners()[0]).right)
	        			engine.getPhysics().usePhysics(engine.getWorld().getPlayer(),engine.getWorld().getPlayer().getLocation().getX()+5,engine.getWorld().getPlayer().getLocation().getY());
	        			
	        			//			engine.getWorld().addParticle(new Particle(engine, engine.getWorld(), engine.getParticleLoader().getImage("particle-00"), engine.getWorld().getPlayer().getLocation().getX(), engine.getWorld().getPlayer().getLocation().getY(),60));
	        		     

	        			
	        			
	        			
	        			
	        			engine.getPhysics().useGravity(engine.getWorld().getPlayer(),engine.getWorld().getPlayer().getLocation().getX(),engine.getWorld().getPlayer().getLocation().getY());
	        			
	        			
	        			
	        			for(Entity e:engine.getWorld().getEntityArray())
	        			{
	        				if(e != null && e.canMove())
	        					e.move();
	        			}
	        			
	        			
	        			engine.repaint();	
	        			try {
	        				Thread.sleep(50);
	        			} catch (InterruptedException e) {
	        				e.printStackTrace();
	        			}
	        		}

			
}
		


	
	}

}
