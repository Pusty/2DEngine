package me.test;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.swing.ImageIcon;

import me.engine.listener.KeyHandler;
import me.engine.listener.MouseHandler;
import me.engine.location.Location;
import me.engine.main.Engine;
import me.engine.physics.SidePhysics;
import me.engine.render.OtherRender;
import me.engine.render.PictureLoader;
import me.engine.render.Render;
import me.engine.render.SheetLoader;
import me.engine.world.World;

public class TestEngine extends Engine {

	public int kills = 0;
	int curmission = 0;

	public static void main(String[] args) {

		Render render = new Render();
		render.setSize(new TestEngine(), 100, 100);
	}

	@Override
	public void init() {
		super.init();

		this.hookPhysic(new TestPhysics(this));
	}

	public void preInit() {

	}

	@Override
	public Image getIconImage() {
		return this.getImageLoader().getImage("icon");

	}

	public void addMouse() {
		MouseHandler mousehandler = new MouseHandler();
		addMouseListener(mousehandler);
		addMouseMotionListener(mousehandler);
	}

	public void initStartImages() {
		super.initStartImages();
		SheetLoader sheet;
		try {
			sheet = new SheetLoader(this.getClass().getResource("players.png"),
					8, 8, 16, 16);
			this.getImageLoader().ImportFromSheet("icon", sheet, 3, 0);
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	public void paint(Graphics g) {
		Graphics2D g2 = (Graphics2D) g.create();
		BufferedImage screen = new BufferedImage(this.getWidth(),
				this.getHeight(), 4);
		Graphics g3 = screen.getGraphics();

		for (OtherRender render : this.getRenderClass()) {
			if (render.getInitStart())
				render.render(this, g3);
		}

		g.drawImage(screen, 0, 0, this);

	}

	public void update(Graphics g) {
		BufferedImage screen = new BufferedImage(this.getWidth(),
				this.getHeight(), 4);
		Graphics g3 = screen.getGraphics();

		for (OtherRender render : this.getRenderClass()) {
			render.render(this, g3);
		}

		g.drawImage(screen, 0, 0, this);

	}

	@Override
	public void addKeys() {
		TestKeyHandler keyhandler = new TestKeyHandler(this);
		addKeyListener(keyhandler);
	}

	@Override
	public void addGameTick() {
		this.addTickClass(new TestTicks(this));
	}

	@Override
	public void initWorld() {

		// this.setWorld(new TestWorld());
		this.setWorld(this.getNextWorld());
	}

	@Override
	public void addRenderClass() {
		this.addRenderClass(new EntityRender());
	}

	@Override
	public Location getStartLocation() {
		return new Location(10, 10);
	}

	@Override
	public void initParticles() {
		SheetLoader sheet;
		try {
			sheet = new SheetLoader(
					this.getClass().getResource("particle.png"), 8, 8, 16, 16);
			this.getParticleLoader().ImportFromSheet("jump-green", sheet, 0, 0);
			this.getParticleLoader().ImportFromSheet("jump-red", sheet, 1, 0);
			this.getParticleLoader().ImportFromSheet("jump-blue", sheet, 4, 0);
			this.getParticleLoader().ImportFromSheet("splash-green", sheet, 2,0);
			this.getParticleLoader().ImportFromSheet("splash-red", sheet, 3, 0);
			this.getParticleLoader().ImportFromSheet("splash-blue", sheet, 5, 0);
			this.getParticleLoader().ImportFromSheet("splash-wood", sheet, 6, 0);
			this.getParticleLoader().ImportFromSheet("splash-door", sheet, 7, 0);

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void initClient() {
		// TODO Automatisch generierter Methodenstub

	}

	@Override
	public void initServer() {
		// TODO Automatisch generierter Methodenstub

	}

	public World getFirstWorld() {
		TestWorld world = new TestWorld();

		world.setPlayer(new Player(this, this.getStartLocation().getX(), this
				.getStartLocation().getY()));

		{

			for (int i = 0; i < 50; i++)
				if (i % 2 == 0)
					world.addEntity(new Wall(32 * i, 50, 2));
			for (int i = 0; i < 50; i++)
				if (!(i % 2 == 0))
					world.addEntity(new Wall(32 * i, 50, 3));

			for (int i = 0; i < 20; i++)
				world.addEntity(new Wall(-32, 50 - 32 * i, 5));
			for (int i = 0; i < 20; i++)
				world.addEntity(new Wall(32 * 50, 50 - 32 * i, 5));

			for (int i = 0; i < 10; i++)
				world.addEntity(new Wall(32 * i + 64, 50 - 96, 4));
			for (int i = 0; i < 5; i++)
				world.addEntity(new Enemy(this, 32 * 10 + 64, 50 - 96 - i * 32));

			for (int i = 0; i < 10; i++)
				world.addEntity(new Wall(32 * i + 64 * 10, 50 - 96, 4));
			for (int i = 0; i < 5; i++)
				world.addEntity(new Jumper(this, 32 * 10 + 64 * 10,
						50 - 96 - i * 32));

			for (int i = 0; i < 10; i++)
				world.addEntity(new Wall(32 * -2 + 64 + 32 * i, 50 - 96 - 96, 4));
			for (int i = 0; i < 5; i++)
				world.addEntity(new Enemy(this, 32 * -2 + 64 + 32 * i,
						50 - 96 - 96 - (i + 1 * 132)));

			world.addEntity(new Wall(32 * 50 - 32, 50 - 32, 6));
			// this.getWorld().addEntity(new Enemy(this,50,0));

		}
		return world;
	}

	public World getNextWorld() {
		if (curmission == 0)
			return getFirstWorld();
		else if (curmission == 1) {
			TestWorld world = new TestWorld();
			world.setPlayer(new Player(this, this.getStartLocation().getX(),
					this.getStartLocation().getY()));

			
			world.addEntity(new Wall(32 * 100-32, 50-32, 6));
			
			
			for (int i = 0; i < 100; i++)
				world.addEntity(new Wall(32 * i, 50, 5));
			
			
			for (int i = 0; i < 100; i++)
				world.addEntity(new Wall(32 * i, 32 - 32 * 39, 5));
			for (int i = 0; i < 40; i++)
				world.addEntity(new Wall(-32, 50 - 32 * i, 5));
			for (int i = 1; i < 40; i++)
				world.addEntity(new Wall(32 * 100, 32 - 32 * i + 50, 5));

			for (int i = 0; i < 5; i++)
				world.addEntity(new Wall(32 * i + 32 * 5, 50 - 32 * 3, 4));
			world.addEntity(new Enemy(this, 32 * 3 + 32 * 5, 50 - 32 - 32 * 3));

			for (int i = 0; i < 5; i++)
				world.addEntity(new Wall(32 * i + 32 * 10, 50 - 32 * 5, 4));

			for (int i = 0; i < 6; i++)				
				world.addEntity(new Wall(32 * i + 32 * 15, 50 - 32 * 8, 8));
			
			world.addEntity(new JumpBlock(32 * 5 + 32 * 15, 50 - 32 * 9));
			

			for (int i = 0; i < 6; i++)
				if(i != 3)
				world.addEntity(new Wall(32 * i + 32 * 30, 50 - 32 * 3, 8));
			
			world.addEntity(new DoorBlock(this, 32 * 3 + 32 * 30, 50 - 32 * 3,true,1));
			
			

			

			
			
	
			world.addEntity(new Enemy(this, 32 * 3 + 32 * 30, 50 - 32 * 4));

			
			
			world.addEntity(new JumpBlock(32 * 5 + 32 * 30, 50 - 32 * 4));

			for (int i = 0; i < 6; i++)
				world.addEntity(new Wall(32 * i + 32 * 30 + 32 * 9, 50 - 32 * 3
						- 32 * 8, 8));

			world.addEntity(new JumpBlock(32 * 5 + 32 * 30 + 32 * 9, 50 - 32
					* 3 - 32 * 9));
			
			world.addEntity(new Jumper(this, 32 * 5 + 32 * 28 + 32 * 9, 50 - 32
					* 3 - 32 * 9));

			world.addEntity(new JumpBlock(32 * 5 + 32 * 30 + 32 * 10, 50 - 32
					* 3 - 32 * 15));
			
			
			
			
			for(int i=0;i<5;i++)
			world.addEntity(new DoorBlock(this,32 * 5 + 32 * 30 + 32 * 12+i*32, 50 - 32* 3 - 32 * 19,false,1));
			
			for(int i=0;i<6;i++)
				world.addEntity(new WoodBlock(this, 32 * 8 + 32 * 30 + 32 * 12+6*32+32*i, 50 - 32* 3 - 32 * 19+32*i));
			
			
			
			for(int i=0;i<15;i++)
				if(i>8)
				world.addEntity(new Wall(32 * 8 + 32 * 30 + 32 * 12+6*32+32*8, 50 - 32* 3 - 32 * 19+32*i-32*5, 5));
				else if(i<8)
			    world.addEntity(new Wall(32 * 8 + 32 * 30 + 32 * 12+6*32+32*8, 50 - 32* 3 - 32 * 19+32*i-32*5, 4));
			
			for(int i=0;i<12;i++)
				world.addEntity(new DoorBlock(this,32 * 8 + 32 * 30 + 32 * 12+6*32+32*8, 50 - 32* 3 - 32 * 19+32*0-32*6-32*i, false,2));
			
			
			world.addEntity(new DoorBlock(this,32 * 8 + 32 * 30 + 32 * 12+6*32+32*8, 50 - 32* 3 - 32 * 19+32*3,true,2));
			
			
			
			
			
			for(int i=1;i<5;i++)
				world.addEntity(new DoorBlock(this,32 * 8 + 32 * 30 + 32 * 12+32*i+6*32+32*8, 50 - 32* 3 - 32 * 19+32*0-32*6, false,2));
			for(int i=1;i<6;i++)
				world.addEntity(new WoodBlock(this,32 * 8 + 32 * 30 + 32 * 12+32*i+6*32+32*8, 50 - 32* 3 - 32 * 19+32*0-32*6+32));
			
			
			world.addEntity(new Enemy(this,32 * 8 + 32 * 30 + 32 * 12+32*3+6*32+32*8, 50 - 32* 3 - 32 * 19+32*0-32*6-32));
			world.addEntity(new Enemy(this,32 * 8 + 32 * 30 + 32 * 12+32*4+6*32+32*8, 50 - 32* 3 - 32 * 19+32*0-32*6-32));
			
			for (int i = 10; i < 90; i++)
				world.addEntity(new Wall(32 * i, 50 - 32 - 3, 7));

			return world;

		}
		return getFirstWorld();
	}

	@Override
	public void playSound(int x, int y, String name) {
		if (Location.getDistanceX(new Location(x, y), this.getWorld()
				.getPlayer().getLocation()) < 1300
				&& Location.getDistanceY(new Location(x, y), this.getWorld()
						.getPlayer().getLocation()) < 1300)
			this.getSoundLoader().playClip(name);
	}

	@Override
	public void initSounds() {
		this.getSoundLoader().addSound("jump",
				this.getClass().getResource("jump.wav"));
		this.getSoundLoader().addSound("jump2",
				this.getClass().getResource("jump2.wav"));
		this.getSoundLoader().addSound("spring",
				this.getClass().getResource("spring.wav"));
		this.getSoundLoader().addSound("portal",
				this.getClass().getResource("portal.wav"));
		this.getSoundLoader().addSound("disappear",
				this.getClass().getResource("disappear.wav"));	
		this.getSoundLoader().addSound("click",
						this.getClass().getResource("click.wav"));

	}
}
